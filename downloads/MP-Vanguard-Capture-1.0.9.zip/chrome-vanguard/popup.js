const $=id=>document.getElementById(id);let tabId,state,selected=new Set(),draft=new Map();const resourceLabels={pe:'Purple Essence',Order:'Order Jewels',Nature:'Nature Jewels',Chaos:'Chaos Jewels',regatta:'Regatta Tickets',chariot:'Chariot Tickets',sov:'SOVs (Seals of Valor)'};
const key=e=>e.gameId?'id:'+e.gameId:e.name?'name:'+e.name:e.path;
function download(data,name){const u=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:name.endsWith('.vcef')?'application/octet-stream':'application/json'}));const a=document.createElement('a');a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),1000)}
async function render(){state=(await chrome.storage.local.get('capture:'+tabId))['capture:'+tabId]||{entries:[],resources:{},responses:0};$('status').textContent=state.enabled?'Reading Vanguard levels and resources…':state.entries.length?'Ready to review':'Ready';if(state.autoStatus){const messages={downloading:'Saving your VCEF capture…',waiting:'Game reloading. Click Play when it appears; capture will continue automatically.',complete:'VCEF saved · ready to import.',review:state.exportError||'Review the capture and export manually.',error:state.exportError||'Extraction could not complete.'};$('status').textContent=messages[state.autoStatus]||$('status').textContent;if(state.autoStatus==='waiting'&&Date.now()-state.startedAt>60000)$('status').textContent='Still waiting. If Play is visible, click it once. Keep the game open while capture finishes.'}$('profile-status').textContent=state.gameProfileId?'Profile ID · '+state.gameProfileId:'';$('profile-status').hidden=!state.gameProfileId;if(state.accountLabel&&!$('label').value)$('label').value=state.accountLabel;$('entries').replaceChildren();for(const e of state.entries){const row=document.createElement('div');row.className='entry';const check=document.createElement('input');check.type='checkbox';check.checked=selected.has(key(e));check.onchange=()=>check.checked?selected.add(key(e)):selected.delete(key(e));const body=document.createElement('div'),title=document.createElement('strong');title.textContent=`ID ${e.gameId||'not supplied'} · Level ${e.level}`;const select=document.createElement('select');const blank=document.createElement('option');blank.value='';blank.textContent='Choose known Vanguard…';select.append(blank);for(const name of VanguardNames){const option=document.createElement('option');option.value=name;const unit=VanguardUnits.find(v=>v.name===name);option.textContent=name+(unit?' · '+unit.rarity:'');select.append(option)}select.value=draft.get(key(e))??e.name??'';select.onchange=async()=>{draft.set(key(e),select.value);selected.delete(key(e));check.checked=false;if(e.gameId&&select.value){const current=(await chrome.storage.local.get('id-mappings'))['id-mappings']||{};current[e.gameId]=select.value;await chrome.storage.local.set({'id-mappings':current})}};const source=document.createElement('small');source.textContent=e.endpoint+' · '+e.source;const meta=document.createElement('small');const unit=VanguardUnits.find(v=>v.name===select.value);meta.textContent=unit?unit.rarity+' · '+unit.faction+' · '+unit.attackType:'';body.append(title,select,meta,source);row.append(check,body);$('entries').append(row)}$('resources').textContent=Object.entries(state.resources).map(([k,v])=>`${resourceLabels[k]}: ${v.toLocaleString()}`).join(' · ')||'No explicitly named resource fields captured yet.';const pending=Object.entries(state.resourceCandidates||{}).map(([k,v])=>k+': '+v.toLocaleString()).join(' · ');if(pending)$('resources').textContent+=' | Ticket fields awaiting mapping (not exported): '+pending;}
$('select-matched').onclick=async()=>{selected.clear();const used=new Set();for(const e of state.entries){const name=draft.get(key(e))??e.name;if(VanguardNames.includes(name)&&!used.has(name)){selected.add(key(e));used.add(name)}}await render()};$('clear-selected').onclick=async()=>{selected.clear();await render()};
$('extract').onclick=async()=>{try{$('extract').disabled=true;selected.clear();draft.clear();$('label').value='';const rawId=$('game-profile-id').value.trim();if(rawId&&!VanguardProfileIdentity.normalize(rawId))throw Error('Enter a numeric game profile ID.');const r=await chrome.runtime.sendMessage({type:'extract',tabId,gameProfileId:rawId||null});$('game-profile-id').value='';if(r?.error)throw Error(r.error);$('status').textContent='Reloading game… click Play when it appears.'}catch(e){$('status').textContent=e.message}finally{$('extract').disabled=false}};
$('start').onclick=async()=>{const r=await chrome.runtime.sendMessage({type:'start',tabId});if(r?.error){$('status').textContent=r.error;return}selected.clear();draft.clear();$('label').value='';await render();$('status').textContent+=' · Refresh the game tab now.'};$('cache').onclick=async()=>{try{const r=await chrome.runtime.sendMessage({type:'cache',tabId});if(r?.error)throw Error(r.error);$('status').textContent='Reading the existing game cache… Wait a moment, then export diagnostics.'}catch(e){$('status').textContent=e.message}};$('stop').onclick=async()=>{await chrome.runtime.sendMessage({type:'stop',tabId});await render()};
$('export').onclick=()=>{try{const rawId=$('game-profile-id').value.trim(),manualId=VanguardProfileIdentity.normalize(rawId),detected=VanguardProfileIdentity.normalize(state.gameProfileId);if(rawId&&!manualId)throw Error('Enter a numeric game profile ID.');if(state.profileIdConflict)throw Error('Conflicting game profile IDs. Capture the correct account again.');if(manualId&&detected&&manualId!==detected)throw Error('The entered profile ID does not match the captured account.');const gameProfileId=detected||manualId||VanguardProfileIdentity.normalize(state.expectedProfileId);const entries=state.entries.filter(e=>selected.has(key(e))).map(e=>({gameId:e.gameId,name:draft.get(key(e))??e.name,level:e.level}));if(!entries.length&&!Object.keys(state.resources).length)throw Error('Check entries to export.');const names=new Set();for(const e of entries){if(!VanguardNames.includes(e.name))throw Error('Choose a known Vanguard for every checked entry.');if(names.has(e.name))throw Error('Check only one entry for '+e.name);names.add(e.name)}download({format:'mp-vanguard-extract',schemaVersion:1,gameProfileId,profileIdSource:detected?state.profileIdSource||'game':gameProfileId?'manual':null,accountLabel:$('label').value.trim()||'Chrome capture',capturedAt:state.capturedAt,entries,resources:state.resources},'vanguard-capture.vcef')}catch(e){$('status').textContent=e.message}};
$('diagnostic').onclick=()=>download({format:'mp-vanguard-diagnostics',version:2,extensionVersion:chrome.runtime.getManifest().version,responses:state.responses,candidates:state.entries,resourceKeys:Object.keys(state.resources),resourceCandidates:state.resourceCandidates||{},unitConfig:state.unitConfig||null,cacheReports:state.cacheReports||{},diagnostics:state.diagnostics},'vanguard-diagnostics.json');
chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes['capture:'+tabId]&&!document.activeElement?.matches('select,input'))render()});(async()=>{const [tab]=await chrome.tabs.query({active:true,currentWindow:true});tabId=tab.id;await render()})().catch(e=>$('status').textContent=e.message);

let heroBusy = false;
async function renderHeroes() {
  const key = 'hero-diagnostics:' + tabId;
  const state = (await chrome.storage.session.get(key))[key];
  $('hero-start').disabled = heroBusy;
  $('hero-catalog-cache').disabled = heroBusy || !state?.enabled;
  $('hero-export').disabled = heroBusy || !state?.responses;
  if (state?.enabled) {
    $('hero-status').textContent = state.responses
      ? (state.reports.find(report => report.roster?.heroes?.length)?.roster.heroes.length
        ? (state.reports.some(report => report.catalog?.length) ? 'Hero catalog candidates captured. Download diagnostics.' : 'Hero roster captured. Read the cached catalog to check for names.')
        : state.responses + ' responses seen. Open a hero, then download.')
      : 'Waiting for game data. Click Play when it appears.';
  } else {
    $('hero-status').textContent = state?.responses ? 'Capture ready to download again.' : 'Ready';
  }
}

async function heroCommand(type, onSuccess) {
  if (heroBusy) return;
  heroBusy = true;
  $('hero-start').disabled = $('hero-export').disabled = true;
  try {
    const result = await chrome.runtime.sendMessage({ type, tabId });
    if (!result || result.error) throw Error(result?.error || 'Try opening the extension again.');
    onSuccess(result);
    heroBusy = false;
    await renderHeroes();
    if (type === 'hero-catalog-cache') $('hero-status').textContent = 'Cache scan requested. Wait a few seconds before downloading.';
    if (type === 'hero-finish') $('hero-status').textContent = 'Hero diagnostics downloaded.';
  } catch (error) {
    heroBusy = false;
    await renderHeroes();
    $('hero-status').textContent = error.message;
  }
}

$('hero-catalog-cache').onclick = () => heroCommand('hero-catalog-cache', () => {});
$('hero-start').onclick = () => heroCommand('hero-start', () => {});
$('hero-export').onclick = () => heroCommand('hero-finish', ({ state }) => {
  download({
    format: 'mp-hero-diagnostics',
    schemaVersion: 2,
    extensionVersion: chrome.runtime.getManifest().version,
    capturedAt: new Date().toISOString(),
    responsesSeen: state.responses,
    reportsOmitted: state.omitted,
    reports: state.reports
  }, 'mp-hero-diagnostics.json');
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'session' && changes['hero-diagnostics:' + tabId] && !heroBusy) renderHeroes();
});
(async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab) {
    tabId = tab.id;
    await renderHeroes();
  }
})().catch(error => $('hero-status').textContent = error.message);
