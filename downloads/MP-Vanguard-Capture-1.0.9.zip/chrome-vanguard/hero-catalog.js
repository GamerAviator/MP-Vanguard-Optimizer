(() => {
  const safeId = value => /^\d{1,8}$/.test(String(value));
  const staticName = name => /^[A-Za-z][A-Za-z0-9_.-]{0,99}$/.test(name) &&
    !/token|session|auth|password|profile|secret/i.test(name);
  const englishFile = name => /^(?:common|start)_published_en\.txt$/i.test(name);
  const candidate = name => englishFile(name) || staticName(name) &&
    /monster|hero|cards?|unit|locali[sz]|translation|dictionary/i.test(name) &&
    !/guildwar|vanguard|roulette|reward|shop|event|archers|stickman|fog|labyrinth/i.test(name);
  const safeText = value => typeof value === 'string' &&
    /^[\p{L}\p{N}][\p{L}\p{N} _.,:!'’()&-]{0,89}$/u.test(value) &&
    !/[a-f0-9]{20}/i.test(value);
  const numeric = value => Number.isSafeInteger(value) || safeId(value);
  const clean = value => String(value).replace(/[^a-z0-9]/gi, '').toLowerCase();
  const metadataField = /^(?:name|title|(?:hero|monster|card|unit|display|localized)(?:name|title)|namekey|titlekey|rarity|quality|faction|alignment|attacktype|type|evolves?(?:from|to)(?:id|ids)?|evolution(?:id|ids|from|to)|evolve(?:id|ids|target))$/;
  const idField = /^(?:ids?|keys|(?:hero|monster|card|unit|creature|template|config|record)ids?)$/;
  const labelKey = key => staticName(key) &&
    /(?:monster|hero|card|unit)/i.test(key) && /(?:name|title|\d)/i.test(key) &&
    !/description|skill|ability|bonus|upgrade|quest|event|button|tooltip/i.test(key);
  const columnField = key => metadataField.test(clean(key)) ||
    /name|title|rarity|faction|align|evol|transform|promote|race|sprite/i.test(key);

  function localization(value) {
    const rows = new Map();
    const add = (key, name) => {
      if (rows.size < 3000 && labelKey(key) && safeText(name)) rows.set(key, {key, name});
    };
    if (typeof value === 'string') {
      for (const line of value.split(/\r?\n/)) {
        const match = line.match(/^\s*["']?([\w.-]+)["']?\s*[:=;,\t]\s*["']?(.+?)["',;]?\s*$/);
        if (match) add(match[1], match[2]);
        const xml = line.match(/<(?:string|entry)\s+(?:name|key)="([^"]+)">([^<]+)</i);
        if (xml) add(xml[1], xml[2]);
      }
    } else {
      let visited = 0;
      function walk(node, depth) {
        if (!node || typeof node !== 'object' || depth > 9 || ++visited > 35000 || rows.size >= 3000) return;
        const key = node.key ?? node.id;
        if (typeof key === 'string') add(key, node.value ?? node.text ?? node.en);
        for (const [field, item] of Object.entries(node)) {
          if (typeof item === 'string') add(field, item);
          else walk(item, depth + 1);
        }
      }
      walk(value, 0);
    }
    return rows.size ? [{path:'$.localization',rows:[...rows.values()]}] : [];
  }

  function columns(value) {
    const results = [];
    function walk(node, path, depth) {
      if (!node || typeof node !== 'object' || Array.isArray(node) || depth > 5 || results.length >= 10) return;
      const entries = Object.entries(node).filter(([key]) => staticName(key));
      const arrays = entries.filter(([, item]) => Array.isArray(item));
      const idColumns = arrays.filter(([key, items]) =>
        idField.test(clean(key)) && items.length && items.every(safeId));
      for (const [idKey, ids] of idColumns.slice(0, 4)) {
        const fields = arrays.filter(([key, items]) => key !== idKey && columnField(key) && items.length === ids.length);
        if (!fields.length) continue;
        const rows = ids.slice(0, 2200).map((id, index) => {
          const row = {id:Number(id)};
          for (const [key, values] of fields) {
            const item = values[index];
            if (numeric(item) || safeText(item)) row[key] = item;
            else if (Array.isArray(item)) row[key] = item.filter(x => numeric(x) || safeText(x)).slice(0, 12);
          }
          return row;
        });
        results.push({path:path+'.'+idKey,rows});
      }
      if (arrays.some(([key]) => /rarity|name|title/i.test(key))) {
        results.push({path:path+'.column-shape',rows:[],columns:arrays.slice(0,80).map(([key,items]) => ({
          key,length:items.length,
          ...(idField.test(clean(key)) || columnField(key) ? {sample:items.slice(0,3).map(item => numeric(item) || safeText(item) ? item : null)} : {})
        }))});
      }
      for (const [key,item] of entries) walk(item,path+'.'+key,depth+1);
    }
    walk(value,'$',0);
    return results;
  }

  function scan(value, filename = '') {
    if (englishFile(filename)) return localization(value);
    const tableGroups = columns(value);
    if (tableGroups.some(group => group.rows.length)) return tableGroups;
    const groups = new Map();
    let visited = 0;
    let saved = 0;
    function walk(node, route, key, depth) {
      if (++visited > 65000 || saved >= 1600 || depth > 11 || !node || typeof node !== 'object') return;
      const entries = Object.entries(node);
      if (!Array.isArray(node)) {
        const explicit = entries.find(([field, item]) => idField.test(clean(field)) && safeId(item));
        const id = explicit?.[1] ?? (safeId(key) ? key : null);
        const fields = {};
        if (id === null && /locali[sz]|translation|dictionary/i.test(route)) {
          const heroLabels = entries.filter(([field, item]) =>
            /^(?:monster|hero|card|unit)[_.-].*(?:name|title|[_.-]\d+)$/i.test(field) &&
            staticName(field) && safeText(item));
          if (heroLabels.length && (groups.has(route) || groups.size < 18)) {
            if (!groups.has(route)) groups.set(route, []);
            for (const [key, name] of heroLabels.slice(0, 1600 - saved)) {
              groups.get(route).push({key, name});
              saved++;
            }
          }
        }
        if (id !== null || safeText(key) && !/token|session|password|profile|secret/i.test(key)) {
          for (const [field, item] of entries) {
            if (!metadataField.test(clean(field)) || !staticName(field)) continue;
            if (numeric(item) || safeText(item)) fields[field] = item;
            else if (Array.isArray(item)) fields[field] = item.filter(x => numeric(x) || safeText(x)).slice(0, 16);
          }
          if (Object.keys(fields).length && (groups.has(route) || groups.size < 18)) {
            if (!groups.has(route)) groups.set(route, []);
            groups.get(route).push({...(id === null ? {key} : {id:Number(id)}), ...fields});
            saved++;
          }
        }
      }
      for (const [child, item] of entries) {
        if (visited >= 65000 || saved >= 1600) break;
        if (!item || typeof item !== 'object' || !(staticName(child) || safeId(child))) continue;
        const segment = safeId(child) ? '[]' : child;
        walk(item, route + '.' + segment, Array.isArray(node) ? '' : child, depth + 1);
      }
    }
    walk(value, '$', '', 0);
    return [...tableGroups, ...[...groups].map(([path, rows]) => ({path, rows}))];
  }

  function names(value) {
    const config = value?.result?.config_data;
    return config && typeof config === 'object' ? Object.keys(config).filter(staticName).slice(0, 900) : [];
  }

  function publish(endpoint, catalog, configNames = []) {
    window.postMessage({source:'mp-hero-diagnostics-v1', report:{
      endpoint, catalog, configNames, collections:[], hints:[], balances:{}, truncated:false
    }}, location.origin);
  }
  globalThis.MPHeroCatalog = {candidate, englishFile, staticName, scan, names, publish};
})();
