// Read only explicitly named static unit config files from the game's IDBFS.
(()=>{let busy=false;const publish=(endpoint,data)=>window.postMessage({source:'mp-vanguard-capture-v1',endpoint,data},location.origin);
 const names=keys=>keys.filter(k=>typeof k==='string'&&/config|guildwar|archer/i.test(k)&&!/token|session|profile|password|secret/i.test(k)).slice(0,100).map(k=>k.split('/').at(-1).slice(0,180));
 function files(db, catalog){return new Promise((resolve,reject)=>{const tx=db.transaction('FILE_DATA','readonly'),store=tx.objectStore('FILE_DATA'),req=store.getAllKeys(undefined,5000),found=[];let keys=[];req.onerror=()=>reject(req.error);req.onsuccess=()=>{keys=req.result;for(const key of keys.filter(k=>typeof k==='string'&&(catalog ? MPHeroCatalog.candidate(k.split('/').at(-1)) : /(^|[^a-z])GuildWarUnits([^a-z]|$)/i.test(k))).slice(0,catalog?90:6)){const get=store.get(key);get.onsuccess=()=>found.push({key,value:get.result})}};tx.oncomplete=()=>resolve({keys,found});tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||Error('Cache read aborted'))})}
 function openExisting(){return new Promise(async(resolve,reject)=>{try{if(typeof indexedDB.databases!=='function')throw Error('Database listing unavailable');const known=await indexedDB.databases();if(!known.some(d=>d.name==='/idbfs'))return resolve(null);const request=indexedDB.open('/idbfs');request.onupgradeneeded=()=>{request.transaction.abort();reject(Error('Existing cache unavailable'))};request.onerror=()=>reject(request.error);request.onsuccess=()=>resolve(request.result)}catch(e){reject(e)}})}
 async function decodeFile(value, plainText = false){let contents=value?.contents;if(contents===undefined)throw Error('No contents field in cached file');if(typeof contents==='string'){try{return JSON.parse(contents)}catch{if(plainText&&contents.length<=12000000)return contents;throw Error('Cached file is text but not JSON')}}let bytes;if(ArrayBuffer.isView(contents))bytes=new Uint8Array(contents.buffer,contents.byteOffset,contents.byteLength);else if(contents instanceof ArrayBuffer)bytes=new Uint8Array(contents);else if(contents instanceof Blob)bytes=new Uint8Array(await contents.arrayBuffer());else if(Array.isArray(contents))bytes=new Uint8Array(contents);else throw Error('Unsupported cached content type');if(bytes.length>12000000)throw Error('Cached config exceeds limit');if(bytes[0]===0x1f&&bytes[1]===0x8b){const stream=new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));bytes=new Uint8Array(await new Response(stream).arrayBuffer());if(bytes.length>12000000)throw Error('Decoded config exceeds limit')}const text=new TextDecoder().decode(bytes);try{return JSON.parse(text)}catch{return plainText?text:VanguardMsgpack.decode(bytes)}}
 async function read(){if(busy)return;busy=true;let db;const summary={origin:location.hostname,totalKeys:0,matchedFiles:0,configFileNames:[],issues:[]};try{db=await openExisting();if(!db){summary.issues.push('No IDBFS database in this frame');return}if(!db.objectStoreNames.contains('FILE_DATA')){summary.issues.push('No FILE_DATA store');return}const {keys,found}=await files(db);summary.totalKeys=keys.length;summary.matchedFiles=found.length;summary.configFileNames=names(keys);for(const item of found){try{const decoded=await decodeFile(item.value);publish('/cc_api/configs_msgpack/cached/GuildWarUnits',decoded)}catch(e){summary.issues.push(item.key.split('/').at(-1).slice(0,100)+': '+e.message)}}if(!found.length)summary.issues.push('No file key explicitly named GuildWarUnits; no unrelated file values were read')}catch(e){summary.issues.push(e.message)}finally{db?.close();busy=false;publish('/local-cache/unit-config-scan',{cacheSummary:summary})}}
 async function readCatalog(){
  let db;
  const cacheNames=[];
  try{
   db=await openExisting();
   if(!db?.objectStoreNames.contains('FILE_DATA'))return;
   const {keys,found}=await files(db,true);
   cacheNames.push(...new Set(keys.filter(key=>typeof key==='string'&&/config|monster|hero|locali[sz]|translation/i.test(key)&&!/token|session|auth|password|profile|secret/i.test(key)).map(key=>key.split('/').at(-1)).filter(MPHeroCatalog.staticName)));
   for(const item of found){
    const name=item.key.split('/').at(-1);
    try{MPHeroCatalog.publish('/local-cache/hero-catalog/'+name,MPHeroCatalog.scan(await decodeFile(item.value,MPHeroCatalog.englishFile(name)),name))}
    catch{MPHeroCatalog.publish('/local-cache/hero-catalog/'+name,[])}
   }
  }finally{
   db?.close();
   MPHeroCatalog.publish('/local-cache/hero-catalog-index',[],cacheNames.slice(0,900));
  }
 }
 window.addEventListener('message',e=>{
  if(e.source!==window||e.origin!==location.origin||e.data?.source!=='mp-vanguard-cache-command-v1')return;
  if(e.data.action==='read')read();
  if(e.data.action==='hero-catalog')readCatalog().catch(()=>{});
 });
})();
