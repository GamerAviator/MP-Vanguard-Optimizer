(() => {
  const privateKey = /token|password|passwd|cookie|session|secret|auth|credential|email|phone|address|device|payment|playerid|profileid|accountid|userid|login/i;
  const collectionKey = /heroes|hero|cards|card|units|unit|troop|creature|collection|roster|inventory|souls|shards|reborn|rebirth|evolut|heroesbit/i;
  const excluded = /guildunitsbit|guildwarunits|vanguard|^bankbit$|^chestbit$|^fogarmycollectionbit$/i;
  const fields = /^(?:id|(?:hero|card|unit|troop|creature|template|config|character|[a-z]*type)id|type|rarity|quality|faction|level|lvl|rank|grade|(?:cur|curr|real|current)lvl|(?:cur|curr|real)level|xp|exp|experience|power|might|attack|health|(?:current|hero|card|unit)?level|(?:cur|curr|current|hero|card|unit)?(?:reborn|rebirth)(?:count|level|stage|s|index|rank|times)?|(?:soul|shard|fragment|card|piece|copy|copies|resource)s?(?:count|amount|balance|stock|id|quantity|total)?|(?:count|amount|balance|stock|quantity|value)|(?:is)?(?:owned|unlocked|active)|(?:current|total)?gold(?:balance|amount|stock)?|(?:guild|fable|evolve|reborn|cheapupgrade|upgrade)[a-z]*(?:bonus|discount|percent|rate|enabled)|bonus|discount|percent|percentage)$/i;
  const currencies = /gold|souls|fable|cheap.?upgrade|evolv.*(?:bonus|discount)|reborn.*(?:bonus|discount)/i;
  const normalize = key => key.replace(/[_ -]/g, '');
  const safeKey = key => /^[A-Za-z][A-Za-z0-9_ -]{0,47}$/.test(key) && !/[a-f0-9]{16}/i.test(key);
  const numericKey = key => /^\d{1,9}$/.test(key);
  const scalar = value => typeof value === 'boolean' || Number.isFinite(value) ||
    (typeof value === 'string' && /^-?\d{1,12}(?:\.\d{1,6})?$/.test(value));
  const safePath = path => /^\/(?:[a-z_][a-z0-9_-]{0,39}\/){0,7}[a-z_][a-z0-9_-]{0,39}\/?$/i.test(path) && !/[a-f0-9]{16}/i.test(path);

  const heroFields = /^(?:id|(?:monster|creature|hero|card|unit|template|config|character|type)(?:type)?id|(?:monster|creature|hero|card|unit)?type|staticid|sid|key|name|(?:hero|card|unit|monster)name|localizedname|rarity|quality|faction|race|level|levels|lvl|lv|l|r|rb|xp|exp|experience|upgrades|upgradelevel|upgradescount|attack|health|might|power|tier|rank|grade|(?:[a-z]*)(?:reborn|rebirth|reset|soul|shard|evolv|level)[a-z]*|activesets|(?:is)?(?:owned|unlocked))$/i;
  const relationship = /^(?:data|stats|state|progress|monster|creature|hero|card|unit|template|config|character|identity|prototype|rarity)$/i;
  const stringField = /(?:id|type|name|rarity|quality|faction|race|key)$/i;
  const safeGameString = value => /^[\p{L}\p{N}][\p{L}\p{N} _.\-'’]{0,63}$/u.test(value) &&
    !/[a-f0-9]{20}/i.test(value);

  function scanRoster(collection, resources) {
    const fieldTypes = {};
    let omitted = 0;
    function pick(value, depth) {
      if (scalar(value)) return value;
      if (!value || typeof value !== 'object' || depth > 4) return undefined;
      if (Array.isArray(value)) {
        return value.slice(0, 30).map(item => pick(item, depth + 1) ?? null);
      }
      const result = {};
      for (const [key, item] of Object.entries(value)) {
        if (!safeKey(key) || privateKey.test(key)) continue;
        const field = normalize(key);
        if (depth === 0 && (Object.hasOwn(fieldTypes, key) || Object.keys(fieldTypes).length < 100)) {
          fieldTypes[key] = Array.isArray(item) ? 'array' : item === null ? 'null' : typeof item;
        }
        const directStat = depth === 0 && scalar(item);
        if (!directStat && !heroFields.test(field) && !relationship.test(field) && !fields.test(field)) continue;
        const selected = typeof item === 'string' && stringField.test(field) && safeGameString(item)
          ? item : pick(item, depth + 1);
        if (selected !== undefined) result[key] = selected;
      }
      return result;
    }
    const heroes = [];
    for (const [key, entry] of Object.entries(collection)) {
      if (!entry || typeof entry !== 'object') { omitted++; continue; }
      if (heroes.length >= 2500) { omitted++; continue; }
      const values = pick(entry, 0);
      if (!values || !Object.keys(values).length) { omitted++; continue; }
      const identity = Array.isArray(collection) ? { index: Number(key) } :
        safeGameString(key) && !privateKey.test(key) ? { key } : {};
      heroes.push({ ...identity, values });
    }
    return {
      path: 'result.data.ArmyBit.data.collection',
      gold: typeof resources?.Gold !== 'boolean' && scalar(resources?.Gold) ? resources.Gold : null,
      totalEntries: heroes.length + omitted,
      omitted,
      fieldTypes,
      heroes
    };
  }

  function scan(path, data) {
    if (!safePath(path) || path.split('/').some(part => privateKey.test(part)) || !data || typeof data !== 'object') return null;
    const profileData = path === '/gs_api/profile/load' ? data.result?.data : null;
    const heroCollection = profileData?.ArmyBit?.data?.collection;
    if (heroCollection && typeof heroCollection === 'object') {
      const roster = scanRoster(heroCollection, profileData.ResourceBit?.data?.resources);
      return { endpoint: path, roster, collections: [], hints: [], balances: {}, truncated: roster.omitted > 0 };
    }
    const collections = new Map();
    const hints = new Set();
    const balances = {};
    const shape = new Set();
    const profile = path === '/gs_api/profile/load';
    const cardResponse = /^\/gs_api\/cards\/get_card\/?$/.test(path);
    const shapeFields = /^(?:(?:cur|curr|current|hero|card|unit)?(?:level|lvl)|reborn(?:count|level|stage)?|rebirth(?:count|level|stage)?|souls?(?:count|amount|stock|balance)?|shards?(?:count|amount|stock|balance)?)$/i;
    const maxVisited = profile ? 110000 : 16000;
    const maxRows = cardResponse ? 350 : 900;
    let savedRows = 0;
    let visited = 0;
    let truncated = false;

    function walk(value, route, relevant, entryId) {
      if (++visited > maxVisited) { truncated = true; return; }
      if (!value || typeof value !== 'object' || route.length > 16) return;
      if ((profile && route.length <= 4 || cardResponse && route.length <= 7) &&
          shape.size < 200 && !route.includes('[]')) {
        const label = route.join('.');
        if (label) shape.add(label);
      }
      const rawEntries = Object.entries(value);
      if (profile && route.length === 2) {
        rawEntries.sort(([a], [b]) => Number(collectionKey.test(b)) - Number(collectionKey.test(a)));
      }
      if (!Array.isArray(value)) {
        const stats = {};
        const hasHeroStats = profile && rawEntries.some(([key, item]) =>
          scalar(item) && shapeFields.test(normalize(key)));
        for (const [key, item] of rawEntries) {
          if (privateKey.test(key) || !safeKey(key)) continue;
          if (!scalar(item)) continue;
          const field = normalize(key);
          if (((relevant || hasHeroStats) && fields.test(field)) || currencies.test(field)) stats[key] = item;
          if (currencies.test(field) && Object.keys(balances).length < 40) {
            balances[[...route, key].join('.')] = item;
          }
        }
        if ((relevant || hasHeroStats) && Object.keys(stats).length) {
          const location = route.join('.');
          if (!collections.has(location) && collections.size < 60) collections.set(location, []);
          const rows = collections.get(location);
          if (rows && rows.length < maxRows && savedRows < 1900) {
            rows.push({ ...(entryId ? { entryId } : {}), ...stats });
            savedRows++;
          }
          else truncated = true;
        }
      }
      for (const [key, item] of rawEntries) {
        if (visited >= maxVisited) { truncated = true; break; }
        if (privateKey.test(key) || excluded.test(key) || item === null) continue;
        if (relevant && numericKey(key) && scalar(item)) {
          const location = [...route, '[]'].join('.');
          if (!collections.has(location) && collections.size < 60) collections.set(location, []);
          const rows = collections.get(location);
          if (rows && rows.length < maxRows && savedRows < 1900) {
            rows.push(Array.isArray(value) ? { index: Number(key), value: item } : { entryId: key, value: item });
            savedRows++;
          }
          else truncated = true;
        }
        if (typeof item !== 'object') continue;
        if (Array.isArray(value) || numericKey(key)) {
          walk(item, [...route, '[]'], relevant, Array.isArray(value) ? entryId : key);
        } else if (safeKey(key)) {
          const candidate = collectionKey.test(key);
          if (candidate && hints.size < 100) hints.add([...route, key].join('.'));
          walk(item, [...route, key], relevant || candidate, entryId);
        }
      }
    }
    walk(data, [], cardResponse);
    return { endpoint: path, collections: [...collections].map(([path, rows]) => ({ path, rows })), hints: [...hints], shape: [...shape], balances, truncated };
  }
  globalThis.MPHeroDiagnostics = { scan };
})();
