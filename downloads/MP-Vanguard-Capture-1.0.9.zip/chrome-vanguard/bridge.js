function forward(event){if(event.source!==window||event.origin!==location.origin||event.data?.source!=='mp-vanguard-capture-v1')return;try{const capture=VanguardExtract.scan(event.data.data,String(event.data.endpoint||'').slice(0,150));chrome.runtime.sendMessage({type:'capture',capture:{...capture,documentStartedAt:performance.timeOrigin}}).catch(()=>{})}catch(e){if(/invalidated/i.test(e.message))window.removeEventListener('message',forward)}}window.addEventListener('message',forward);

chrome.runtime.onMessage.addListener((message,sender,reply)=>{if(sender.id===chrome.runtime.id&&['read-unit-cache','read-hero-catalog'].includes(message.type)){window.postMessage({source:'mp-vanguard-cache-command-v1',action:message.type==='read-hero-catalog'?'hero-catalog':'read'},location.origin);reply({requested:true})}});

window.addEventListener('message', event => {
  if (event.source !== window || event.origin !== location.origin ||
      event.data?.source !== 'mp-hero-diagnostics-v1') return;
  try {
    chrome.runtime.sendMessage({
      type: 'hero-report', report: event.data.report, documentStartedAt: performance.timeOrigin
    }).catch(() => {});
  } catch {}
});
