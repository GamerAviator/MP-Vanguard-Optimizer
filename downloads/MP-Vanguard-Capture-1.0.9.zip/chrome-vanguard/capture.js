(()=>{if(window.__vanguardCapture)return;window.__vanguardCapture=true;
 const endpoint=url=>{try{const u=new URL(url,location.href);return /(^|\.)blitzmightyparty\.com$/.test(u.hostname)&&(!u.pathname.includes('/configs_msgpack/')||u.pathname.endsWith('/GuildWarUnits')||MPHeroCatalog.candidate(u.pathname.split('/').filter(Boolean).at(-1) || ''))?u.pathname:null}catch{return null}};
 const publish=(path,value)=>{
 if(path.includes('/configs_msgpack/')&&!path.endsWith('/GuildWarUnits')){
  const groups=MPHeroCatalog.scan(value);
  MPHeroCatalog.publish(path,groups);
  return;
 }
 if(path.endsWith('/get_config_hashes')){
  MPHeroCatalog.publish(path,[],MPHeroCatalog.names(value));
 }
 if(!path.includes('/configs_msgpack/')){
  try{const report=MPHeroDiagnostics.scan(path,value);if(report)window.postMessage({source:'mp-hero-diagnostics-v1',report},location.origin)}catch{}
 }const data=value?.result?.data;if(data?.GuildUnitsBit){value={result:{data:{GuildUnitsBit:data.GuildUnitsBit,ResourceBit:{data:{resources:data.ResourceBit?.data?.resources||{}}},NameBit:{data:{Name:data.NameBit?.data?.Name||''}}}}}}if(value&&typeof value==='object')window.postMessage({source:'mp-vanguard-capture-v1',endpoint:path,data:value},location.origin)};
 const fetch=window.fetch;window.fetch=function(...args){const path=endpoint(args[0] instanceof Request?args[0].url:String(args[0]));const promise=Reflect.apply(fetch,this,args);if(path)promise.then(async r=>{if(r.ok&&Number(r.headers.get('content-length')||0)<32000000){if(path.includes('/configs_msgpack/')){const buffer=await r.clone().arrayBuffer();if(buffer.byteLength<(path.endsWith('/GuildWarUnits')?4000000:12000000))publish(path,VanguardMsgpack.decode(buffer))}else{const text=await r.clone().text();if(text.length<32000000)try{publish(path,JSON.parse(text))}catch{}}}}).catch(()=>{});return promise};
 const open=XMLHttpRequest.prototype.open,send=XMLHttpRequest.prototype.send,paths=new WeakMap();XMLHttpRequest.prototype.open=function(method,url,...rest){paths.set(this,endpoint(url));return Reflect.apply(open,this,[method,url,...rest])};XMLHttpRequest.prototype.send=function(...args){const path=paths.get(this);if(path)this.addEventListener('load',()=>{try{if(this.status<200||this.status>=300)return;let value=this.response;if(this.responseType==='arraybuffer'){if(value.byteLength>32000000)return;value=path.includes('/configs_msgpack/')?VanguardMsgpack.decode(value):JSON.parse(new TextDecoder().decode(value))}else if(this.responseType!=='json'){if(this.responseText.length>32000000)return;value=JSON.parse(this.responseText)}publish(path,value)}catch{}},{once:true});return Reflect.apply(send,this,args)};
})();
