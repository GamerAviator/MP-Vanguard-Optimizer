MIGHTY PARTY VANGUARD CAPTURE — 0.1.8

ONE-CLICK EXTRACTION
1. Open Mighty Party in the Chrome profile that holds the player you want.
2. Open Vanguard Capture and click Extract this account.
3. The extension starts clean and reloads the game. Wait for normal game load.
4. Your JSON automatically downloads as vanguard-PLAYER-DATE.json. The popup
   may close during reload; the background capture/download continues.
5. In the optimizer, choose/create the matching player account, go to Import
   → Import Chrome capture JSON, choose that download, review/select values,
   and apply. Capturing/exporting never changes optimizer accounts directly.

One click handles game extraction and download. Optimizer import retains its
review screen. A browser setting that asks where downloads go may still show
its usual file-save prompt. Unknown IDs, duplicate names or missing balances
stop automatic export and leave data available for manual review/export.
If no profile arrives, reopening the popup after a minute shows retry guidance.

INSTALL / UPDATE IN EACH CHROME PROFILE
1. Extract chrome-vanguard to a permanent folder.
2. Switch to the desired Chrome profile using Chrome's profile selector.
3. Open chrome://extensions and enable Developer mode.
4. New profile: Load unpacked → choose chrome-vanguard (manifest.json).
   Existing profile: replace its extension files and click Reload on its card.
5. Repeat for other profiles. You can select the same permanent folder in each
   profile. Chrome extension storage remains separate for each profile.
6. Pin Vanguard Capture using Chrome's Extensions menu.

Version 0.1.7 adds the downloads permission to save the extracted JSON
without keeping the popup open. Allow it if Chrome requests confirmation.
It does not upload data, click game upgrades, or alter game requests.

MULTIPLE PLAYERS
Always open the correct player's game tab BEFORE clicking Extract this account.
Each run replaces only that tab's extension capture and creates a new download
with an account label. Duplicate filenames are uniquified, not overwritten.
Don't switch game players during an extraction. After a completed download,
the capture stops. For another player, switch profiles/tab and extract again.

Chrome profiles have separate extension/local optimizer storage. An installed
optimizer may also use its own separate storage. Importing into the selected
optimizer account changes only checked values; it does not replace your other
accounts. Verify the selected account and source label on every import.
Back up optimizer accounts routinely. Keep personal JSONs off public GitHub.

FIELDS
Known GuildWarUnits IDs are linked to the 50-card canonical map; no screen
positions are used. Captured config metadata can verify sprite, faction,
attack type and rarity. Unknown/new IDs require explicit review/mapping.
The game config has sprite keys rather than English display names.

GuildUnitsBit.data.UnitLevels supplies Vanguard levels. Four exact upgrade
balances are GuildSpheres (Purple Essence), GuildOrder, GuildNature and
GuildChaos. GuildRoulettePoints supplies SOVs (Seals of Valor), separately
tracked in the optimizer; SOVs do not increase its upgrade budget.
Verified ticket mappings: RegattaPoints → Regatta Tickets;
GuildFogPvpShopResource → Chariot Tickets. Both are exported in manual and
one-click captures when valid balances are present. Missing/invalid fields
are omitted, not replaced with zero. Review ticket balances during import.

MANUAL / TROUBLESHOOTING
Expand Manual capture & troubleshooting for Start fresh capture, Stop and
Read cached unit config. Start fresh capture requires a manual game refresh.
Review detected names/levels, Select matched roster, then Export checked data.
A cache scan reads only GuildWarUnits files from the existing /idbfs FILE_DATA
store using readonly transactions. It never clears or changes that cache.
Export capture diagnostics for troubleshooting. They omit complete profiles,
request headers/bodies and credentials, but contain private roster information.

Responses from documents predating the one-click reload are ignored. Downloads
use the just-captured profile's levels/resources rather than merged older tab
state. All 111 automated tests passed, including multi-account isolation and
one-download behavior. This new automation still needs a live Chrome check.
The existing optimizer/SOV update works with this extension: no new app files
are required for one-click extraction.

0.1.9: Pyro (Order Ranged) and Viryel (Nature Ranged) are now available
in the known-name review list. Their internal game IDs have not yet been
verified. Use Review captured data to identify their unmatched ID rows once
and save those mappings. No IDs are inferred from roster order. Automatic
export leaves unmatched cards out until their identities are reviewed.
