// Bounded MessagePack reader for the game's static GuildWarUnits table.
(()=>{function decode(input){const bytes=new Uint8Array(input),view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),text=new TextDecoder('utf-8',{fatal:true});let p=0,nodes=0;
 function need(n){if(n<0||p+n>bytes.length)throw Error('Truncated MessagePack')}
 function number(method,n){need(n);const v=view[method](p);p+=n;return v}
 function length(n){if(n>200000)throw Error('Config collection too large');return n}
 function raw(n){need(n);const v=bytes.slice(p,p+n);p+=n;return v}
 function str(n){return text.decode(raw(n))}
 function array(n,d){return Array.from({length:length(n)},()=>read(d+1))}
 function map(n,d){const out=Object.create(null);for(let i=0;i<length(n);i++){const k=read(d+1);if(typeof k!=='string'&&typeof k!=='number')throw Error('Unsupported map key');out[String(k)]=read(d+1)}return out}
 function int64(signed){const v=number(signed?'getBigInt64':'getBigUint64',8);const n=Number(v);if(!Number.isSafeInteger(n))throw Error('Unsafe integer in config');return n}
 function ext(n){const type=number('getInt8',1);return {extensionType:type,bytes:Array.from(raw(n))}}
 function read(d=0){if(d>32||++nodes>300000)throw Error('Config nesting limit');const b=number('getUint8',1);if(b<128)return b;if(b>=224)return b-256;if(b>=160&&b<=191)return str(b&31);if(b>=144&&b<=159)return array(b&15,d);if(b>=128&&b<=143)return map(b&15,d);switch(b){case 192:return null;case 194:return false;case 195:return true;case 196:return Array.from(raw(number('getUint8',1)));case 197:return Array.from(raw(number('getUint16',2)));case 198:return Array.from(raw(number('getUint32',4)));case 199:return ext(number('getUint8',1));case 200:return ext(number('getUint16',2));case 201:return ext(number('getUint32',4));case 202:return number('getFloat32',4);case 203:return number('getFloat64',8);case 204:return number('getUint8',1);case 205:return number('getUint16',2);case 206:return number('getUint32',4);case 207:return int64(false);case 208:return number('getInt8',1);case 209:return number('getInt16',2);case 210:return number('getInt32',4);case 211:return int64(true);case 212:return ext(1);case 213:return ext(2);case 214:return ext(4);case 215:return ext(8);case 216:return ext(16);case 217:return str(number('getUint8',1));case 218:return str(number('getUint16',2));case 219:return str(number('getUint32',4));case 220:return array(number('getUint16',2),d);case 221:return array(number('getUint32',4),d);case 222:return map(number('getUint16',2),d);case 223:return map(number('getUint32',4),d);default:throw Error('Unsupported MessagePack byte')}}
 const out=read();if(p!==bytes.length)throw Error('Trailing config bytes');return out}
 globalThis.VanguardMsgpack={decode};})();
